<form wire:submit.prevent="uploadPhoto">
    <input type="file" wire:model="photo" capture="environment" accept="image/*">
    @error('photo') <span class="error">{{ $message }}</span> @enderror
    <button type="submit">Upload Photo</button>
</form>
