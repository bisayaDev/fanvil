<?php

namespace App\Filament\Resources\ReleaseToMembersResource\Pages;

use App\Filament\Resources\ReleaseToMembersResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditReleaseToMembers extends EditRecord
{
    protected static string $resource = ReleaseToMembersResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
