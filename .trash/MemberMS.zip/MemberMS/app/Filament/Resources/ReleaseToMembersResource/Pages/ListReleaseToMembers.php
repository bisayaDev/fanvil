<?php

namespace App\Filament\Resources\ReleaseToMembersResource\Pages;

use App\Filament\Resources\ReleaseToMembersResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListReleaseToMembers extends ListRecords
{
    protected static string $resource = ReleaseToMembersResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
