<?php

namespace App\Filament\Resources\ReleaseToMembersResource\Pages;

use App\Filament\Resources\ReleaseToMembersResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateReleaseToMembers extends CreateRecord
{
    protected static string $resource = ReleaseToMembersResource::class;
}
