<?php

namespace App\Filament\Resources\BarangayResource\RelationManagers;

use App\Models\Barangay;
use Filament\Forms;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class PuroksRelationManager extends RelationManager
{
    protected static string $relationship = 'puroks';

    public function form(Form $form): Form
    {
        return $form
            ->schema([
                TextInput::make('name')
                    ->required()
                    ->label('Purok Name'),
                TextInput::make('purok_leader')
                    ->required()
                    ->label('Purok Leader'),
                TextInput::make('contact_number')
                    ->label('Contact Number'),
                TextInput::make('gcash_number')
                    ->label('GCASH')
            ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')
                    ->label('Purok')
                    ->sortable()
                    ->searchable(),
                TextColumn::make('barangay.name')
                    ->sortable()
                    ->searchable(),
                TextColumn::make('purok_leader')
                    ->label('Purok Leader')
                    ->sortable()
                    ->searchable(),
                TextColumn::make('contact_number')
                    ->label('Contact #')
                    ->sortable()
                    ->searchable(),
                TextColumn::make('gcash_number')
                    ->label('GCASH')
                    ->sortable()
                    ->searchable(),
            ])
            ->filters([
                //
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make(),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }
}
