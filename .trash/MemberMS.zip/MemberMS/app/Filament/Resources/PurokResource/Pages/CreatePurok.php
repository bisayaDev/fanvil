<?php

namespace App\Filament\Resources\PurokResource\Pages;

use App\Filament\Resources\PurokResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePurok extends CreateRecord
{
    protected static string $resource = PurokResource::class;
}
