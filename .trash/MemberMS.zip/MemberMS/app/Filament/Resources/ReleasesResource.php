<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ReleasesResource\Pages;
use App\Filament\Resources\ReleasesResource\RelationManagers;
use App\Filament\Resources\ReleasesResource\RelationManagers\ReleasesRelationManager;
use App\Models\Purok;
use App\Models\Releases;
use App\Models\ReleaseToMembers;
use App\Models\User;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\MarkdownEditor;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Illuminate\Support\Facades\Log;

class ReleasesResource extends Resource
{
    protected static ?string $model = Releases::class;
    protected static ?string $navigationGroup = 'Activities';
    protected static ?string $navigationIcon = 'heroicon-o-gift';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Select::make('purok_id')
                    ->options(Purok::all()->pluck('name','id'))
                    ->label('Purok')
                    ->required(),
                TextInput::make('sponsored_by')
                    ->label('Activity Sponsor'),
                TextInput::make('name')
                    ->required()
                    ->label('Activity Name')
                    ->columnSpan(2),
                DatePicker::make('start_date')
                    ->label('Start Date')->required(),
                DatePicker::make('end_date')
                    ->label('End Date')->required(),
                MarkdownEditor::make('description')
                    ->required()
                    ->label('Activity Description')
                    ->columnSpan(2),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')
                    ->words(5)
                    ->searchable()
                    ->sortable(),
                TextColumn::make('sponsored_by')
                    ->searchable()
                    ->sortable(),
                TextColumn::make('purok.name')
                    ->searchable()
                    ->sortable(),
                TextColumn::make('start_date')
                    ->searchable()
                    ->sortable(),
                TextColumn::make('end_date')
                    ->searchable()
                    ->sortable(),
                TextColumn::make('description')
                    ->words(5)
                    ->searchable()
                    ->sortable(),
            ])
            ->filters([
                SelectFilter::make('purok_id')
                    ->options(Purok::all()->pluck('name','id'))
                    ->multiple()
                    ->label('Purok')
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            ReleasesRelationManager::class
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListReleases::route('/'),
//            'create' => Pages\CreateReleases::route('/create'),
            'edit' => Pages\EditReleases::route('/{record}/edit'),
        ];
    }
}
