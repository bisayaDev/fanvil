<?php

namespace App\Filament\Resources;

use App\Filament\Resources\MembersResource\Pages;
use App\Filament\Resources\MembersResource\RelationManagers;
use App\Models\Barangay;
use App\Models\Members;
use App\Models\Purok;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Illuminate\Support\Facades\Log;

class MembersResource extends Resource
{
    protected static ?string $model = Members::class;

    protected static ?string $navigationGroup = 'Person';
    protected static ?string $navigationIcon = 'heroicon-o-users';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Section::make('Status')
                    ->schema([
                        Toggle::make('active')
                            ->onColor('success')
                            ->offColor('danger')
                            ->default(1),
                        Toggle::make('is_voter')
                            ->onColor('success')
                            ->offColor('danger')
                            ->default(0),
                    ])->columns(2),
                TextInput::make('first_name'),
                TextInput::make('last_name'),
                DatePicker::make('date_of_birth'),
                TextInput::make('email')
                    ->email()
                    ->placeholder('john@example.com'),
                Select::make('purok_id')
                    ->relationship('purok','name')
                    ->label('Purok')
                    ->reactive()
                    ->afterStateUpdated(function (callable $set, callable $get) {
                        $prk = Purok::where('id',$get('purok_id'))->first();
                        $brgy_name = Barangay::where('id',$prk->barangay_id)->first();
                        if (!$brgy_name) {
                            $set('barangay_id', '');
                        } else {
                            $set('barangay_id', $brgy_name->id);
                        }
                    }),
                Select::make('barangay_id')
                    ->label('Barangay')
                    ->relationship('barangay','name'),
                TextInput::make('phone_number')->label('Phone Number'),
                TextInput::make('gcash_number')->label('GCASH'),
                TextInput::make('facebook')
                    ->columnSpan(2)
                    ->placeholder('https://www.facebook.com/username'),
                FileUpload::make('id_image')
                    ->disk('public')
                    ->directory('id_images'),
                FileUpload::make('profile_image')
                    ->disk('public')
                    ->directory('profile_images'),

            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                IconColumn::make('active')
                    ->boolean()
                    ->alignCenter(),
                IconColumn::make('is_voter')
                    ->boolean()
                    ->alignCenter()
                    ->label('Voter'),
                ImageColumn::make('profile_image')
                    ->label('Profile Picture')
                    ->alignCenter(),
                TextColumn::make('first_name')
                    ->label('First Name')
                    ->searchable(),
                TextColumn::make('last_name')
                    ->label('Last Name')
                    ->searchable(),
                TextColumn::make('purok.name')
                    ->label('Purok')
                    ->searchable(),
                TextColumn::make('barangay.name')
                    ->label('Barangay')
                    ->searchable(),
                TextColumn::make('phone_number')
                    ->label('Contact #')
                    ->searchable(),
                TextColumn::make('gcash_number')
                    ->label('GCASH')
                    ->searchable(),
                ImageColumn::make('id_image')
                    ->label('ID Picture')
                    ->alignCenter(),

            ])
            ->filters([
                SelectFilter::make('purok_id')
                    ->options(Purok::all()->pluck('name','id'))
                    ->multiple()
                    ->label('Purok'),
                SelectFilter::make('barangay_id')
                    ->options(Barangay::all()->pluck('name','id'))
                    ->multiple()
                    ->label('Barangay')
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListMembers::route('/'),
//            'create' => Pages\CreateMembers::route('/create'),
//            'edit' => Pages\EditMembers::route('/{record}/edit'),
        ];
    }

}
