<?php

namespace App\Filament\Resources\ReleasesResource\RelationManagers;

use App\Models\members;
use Filament\Forms;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Form;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class ReleasesRelationManager extends RelationManager
{
    protected static string $relationship = 'release_to_members';

    public function form(Form $form): Form
    {
        return $form
            ->schema([
                Select::make('releases')
                    ->relationship('releases','name')
                    ->label('Release Activity')
                    ->columnSpan(2)
                    ->disabledOn(['edit']),
                Select::make('members_id') // Assuming the foreign key that references the member is 'member_id'
                    ->label('Member')
                    ->options(members::all()->pluck('full_name', 'id')->toArray())
                    ->getOptionLabelUsing(fn ($value): ?string =>
                    members::find($value)?->full_name)
                    ->disabledOn(['edit']),
                Textarea::make('notes'),
                Section::make('Status')
                    ->schema([
                        Toggle::make('is_released')
                            ->label('Is Released?')
                            ->onColor('success')
                            ->offColor('danger'),
                        DatePicker::make('release_date'),
                    ])->columns(1)->collapsible()->columnSpan(1),
                Section::make('Release Mode')
                    ->schema([
                        Select::make('mode_of_release')
                            ->options([
                                'GCASH' => 'GCASH',
                                'On-Hand' => 'On-Hand',
                                'Others' => 'Others',
                            ])
                            ->label('Mode of Release'),
                        FileUpload::make('release_proof')
                            ->disk('public')
                            ->directory('release_proof_images'),
                    ])->columns(1)->collapsible()->columnSpan(1)


            ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->recordTitleAttribute('name')
            ->columns([
                TextColumn::make('member.first_name')
                    ->label('Member Name')
                    ->formatStateUsing(function ($state, $record) {
                        return $record->member->first_name . ' ' . $record->member->last_name;
                    }),
                IconColumn::make('is_released')
                    ->label('Is Released')
                    ->boolean()
                    ->alignCenter(),
                TextColumn::make('release_date'),
                TextColumn::make('mode_of_release'),
                ImageColumn::make('release_proof')
                    ->alignCenter(),
                TextColumn::make('user.name')
                    ->label('Process By' ),
                TextColumn::make('notes')
                    ->words(5),
            ])
            ->filters([
                //
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make(),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }
}
