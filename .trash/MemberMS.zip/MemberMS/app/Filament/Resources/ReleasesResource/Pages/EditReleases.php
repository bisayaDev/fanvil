<?php

namespace App\Filament\Resources\ReleasesResource\Pages;

use App\Filament\Resources\ReleasesResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditReleases extends EditRecord
{
    protected static string $resource = ReleasesResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
