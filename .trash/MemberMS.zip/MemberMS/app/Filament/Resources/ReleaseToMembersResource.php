<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ReleaseToMembersResource\Pages;
use App\Filament\Resources\ReleaseToMembersResource\RelationManagers;
use App\Models\members;
use App\Models\Purok;
use App\Models\ReleaseToMembers;
use Filament\Forms;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Illuminate\Support\Facades\Log;

class ReleaseToMembersResource extends Resource
{
    protected static ?string $model = ReleaseToMembers::class;
    protected static ?string $navigationGroup = 'Activities';
    protected static ?string $navigationIcon = 'heroicon-o-rocket-launch';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Select::make('releases')
                    ->relationship('releases','name')
                    ->label('Release Activity')
                    ->columnSpan(2)
                    ->disabledOn(['edit']),
                Select::make('members_id') // Assuming the foreign key that references the member is 'member_id'
                    ->label('Member')
                    ->options(members::all()->pluck('full_name', 'id')->toArray())
                    ->getOptionLabelUsing(fn ($value): ?string =>
                    members::find($value)?->full_name)
                    ->disabledOn(['edit']),
                Textarea::make('notes'),
                Section::make('Status')
                    ->schema([
                        Toggle::make('is_released')
                            ->label('Is Released?')
                            ->onColor('success')
                            ->offColor('danger'),
                        DatePicker::make('release_date'),
                    ])->columns(1)->collapsible()->columnSpan(1),
                Section::make('Release Mode')
                    ->schema([
                        Select::make('mode_of_release')
                            ->options([
                                'GCASH' => 'GCASH',
                                'On-Hand' => 'On-Hand',
                                'Others' => 'Others',
                            ])
                            ->label('Mode of Release'),
                        FileUpload::make('release_proof')
                            ->disk('public')
                            ->directory('release_proof_images'),
                    ])->columns(1)->collapsible()->columnSpan(1)


            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('releases.name')
                    ->label('Release Activity')
                    ->words(4)
                    ->searchable()
                    ->sortable(),
                TextColumn::make('member.first_name')
                    ->label('Member Name')
                    ->formatStateUsing(function ($state, $record) {
                        return $record->member->first_name . ' ' . $record->member->last_name;
                    })
                    ->searchable()
                    ->sortable(),
                IconColumn::make('is_released')
                    ->label('Is Released')
                    ->boolean()
                    ->alignCenter()
                    ->searchable()
                    ->sortable(),
                TextColumn::make('release_date')
                    ->dateTime('M d, Y')
                    ->searchable()
                    ->sortable(),
                TextColumn::make('mode_of_release')
                    ->searchable()
                    ->sortable(),
                ImageColumn::make('release_proof')
                    ->alignCenter()
                    ->searchable()
                    ->sortable(),
                TextColumn::make('user.name')
                ->label('Process By' )
                    ->searchable()
                    ->sortable(),
                TextColumn::make('notes')
                    ->words(5)
                    ->searchable()
                    ->sortable(),
            ])
            ->filters([
                SelectFilter::make('purok_id')
                    ->options(Purok::all()->pluck('name', 'id'))
                    ->multiple()
                    ->label('Purok')
                    ->query(function (Builder $query, array $data) {
                        // Extract the selected purok IDs, fallback to an empty array if 'values' key is not set
                        $selectedPurokIds = $data['values'] ?? [];

                        // Only apply the whereHas condition if there are selected purok IDs
                        if (!empty($selectedPurokIds)) {
                            $query->whereHas('member', function (Builder $query) use ($selectedPurokIds) {
                                $query->whereIn('purok_id', $selectedPurokIds);
                            });
                        }
                        // If $selectedPurokIds is empty, the query remains unmodified, effectively returning all results
                    })
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListReleaseToMembers::route('/'),
            //'create' => Pages\CreateReleaseToMembers::route('/create'),
            //'edit' => Pages\EditReleaseToMembers::route('/{record}/edit'),
        ];
    }
}
