<?php

namespace App\Filament\Resources;

use App\Filament\Resources\PurokResource\Pages;
use App\Filament\Resources\PurokResource\RelationManagers;
use App\Models\Barangay;
use App\Models\Purok;
use Filament\Forms;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class PurokResource extends Resource
{
    protected static ?string $model = Purok::class;
    protected static ?string $navigationGroup = 'Address';

    protected static ?string $navigationIcon = 'heroicon-o-building-office-2';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Select::make('barangay_id')
                    ->options(Barangay::all()->pluck('name','id'))
                    ->label('Barangay')
                    ->required(),
                TextInput::make('name')
                    ->required()
                    ->label('Purok Name'),
                TextInput::make('purok_leader')
                    ->required()
                    ->label('Purok Leader'),
                TextInput::make('contact_number')
                    ->label('Contact Number'),
                TextInput::make('gcash_number')
                    ->label('GCASH')

            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')
                    ->label('Purok')
                    ->sortable()
                    ->searchable(),
                TextColumn::make('barangay.name')
                    ->sortable()
                    ->searchable(),
                TextColumn::make('purok_leader')
                    ->label('Purok Leader')
                    ->sortable()
                    ->searchable(),
                TextColumn::make('contact_number')
                    ->label('Contact #')
                    ->sortable()
                    ->searchable(),
                TextColumn::make('gcash_number')
                    ->label('GCASH')
                    ->sortable()
                    ->searchable(),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPuroks::route('/'),
//            'create' => Pages\CreatePurok::route('/create'),
//            'edit' => Pages\EditPurok::route('/{record}/edit'),
        ];
    }
}
