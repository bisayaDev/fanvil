<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Releases extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'description',
        'start_date',
        'end_date',
        'sponsored_by',
        'purok_id',
    ];

    public function purok()
    {
        return $this->belongsTo(Purok::class);
    }

    public function members()
    {
        return $this->belongsToMany(members::class,'release_to_members')->withTimestamps();
    }

    public function release_to_members()
    {
        return $this->belongsTo(ReleaseToMembers::class,'id','releases_id');
    }

}
