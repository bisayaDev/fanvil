<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Barangay extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'barangay_captain',
        'contact_number',
        'gcash_number',
        ];

    public function puroks()
    {
        return $this->hasMany(Purok::class);
    }
}
