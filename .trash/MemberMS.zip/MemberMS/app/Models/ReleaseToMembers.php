<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ReleaseToMembers extends Model
{
    use HasFactory;

    protected $fillable =[
        'releases_id',
        'members_id',
        'user_id',
        'mode_of_release',
        'release_date',
        'is_released',
        'notes',
        'release_proof'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function member()
    {
        return $this->belongsTo(members::class,'members_id');
    }

    public function releases()
    {
        return $this->belongsTo(Releases::class,'releases_id');
    }
}
