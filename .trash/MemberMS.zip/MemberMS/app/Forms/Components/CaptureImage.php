<?php

namespace App\Forms\Components;

use Filament\Forms\Components\BaseFileUpload;
use Filament\Forms\Components\Field;

class CaptureImage extends BaseFileUpload
{
    protected string $view = 'forms.components.capture-image';
}
