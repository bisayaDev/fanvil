<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('release_to_members', function (Blueprint $table) {
            if (!Schema::hasColumn('release_to_members', 'release_proof')) {
                $table->string('release_proof')->nullable()->after('is_released');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('release_to_members', function (Blueprint $table) {
            if (Schema::hasColumn('release_to_members', 'release_proof')) {
                $table->dropColumn('release_proof');
            }
        });
    }
};
