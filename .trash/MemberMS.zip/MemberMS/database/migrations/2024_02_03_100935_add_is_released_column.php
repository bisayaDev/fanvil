<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('release_to_members', function (Blueprint $table) {
            if (!Schema::hasColumn('release_to_members', 'is_released')) {
                $table->string('is_released')->default(0)->after('release_date');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('release_to_members', function (Blueprint $table) {
            if (Schema::hasColumn('release_to_members', 'is_released')) {
                $table->dropColumn('is_released');
            }
        });
    }
};
